# Xbox 360 Dashboard - Asset Manifest
Este documento define todos os arquivos de imagem necessários para recriar o mockup. 
Todas as imagens DEVEM ser convertidas para formato .dds (DirectDraw Surface) para performance no Xbox 360.

## 🖼️ 1. Game Covers (Tiles)
Caminho: `/assets/covers/`
Tamanho Recomendado: 512x768 px
Formato: DXT5 (com canal Alpha)

| Jogo | Nome do Arquivo | Descrição |
|---|---|---|
| Death Stranding | `death_stranding.dds` | Capa vertical do jogo |
| TLOU Part II | `tlou2.dds` | Capa vertical do jogo |
| Wasteland 3 | `wasteland3.dds` | Capa vertical do jogo |
| Sekiro | `sekiro.dds` | Capa vertical do jogo |
| Ghost of Tsushima | `ghost.dds` | Capa vertical do jogo |
| Hellblade | `hellblade.dds` | Capa vertical do jogo |

## 🖼️ 2. Background Arts (Dynamic)
Caminho: `/assets/bg/`
Tamanho Recomendado: 1280x720 px
Formato: DXT1 (Sem Alpha)

| Jogo | Nome do Arquivo | Descrição |
|---|---|---|
| Death Stranding | `death_stranding_bg.dds` | Arte do Sam Bridges em alta resolução |
| TLOU Part II | `tlou2_bg.dds` | Arte da Ellie em alta resolução |
| ... | ... | ... |

## 🖼️ 3. UI Elements (Static)
Caminho: `/assets/ui/`
Tamanho Recomendado: Variável
Formato: DXT5 (Alpha Obrigatório)

| Elemento | Nome do Arquivo | Descrição |
|---|---|---|
| User Profile | `profile_avatar.dds` | Foto do usuário (Círculo) |
| Icons | `ui_icons.dds` | Atlas de ícones (Trophy, Friends, Store) |
| Cursor | `selection_glow.dds` | Textura de brilho para o card focado |

## 🛠️ Ferramenta de Conversão Recomendada
Use o **Nvidia Texture Tools Exporter** ou o **DirectX Texture Tool** para exportar de PNG -> DDS.
